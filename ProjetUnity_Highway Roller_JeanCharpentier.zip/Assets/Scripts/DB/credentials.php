<?php
    $user = "chje5631_ZeDictator";
    $pwd = "h9VhvcUW7";
    $db = "chje5631_highwayroller";
    $host = "localhost";
?>